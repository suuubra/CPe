﻿namespace DrawingSquares
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSquare = new System.Windows.Forms.Button();
            this.button1x5 = new System.Windows.Forms.Button();
            this.button5x5 = new System.Windows.Forms.Button();
            this.pictureBoxGraphics = new System.Windows.Forms.PictureBox();
            this.textBoxNumSquares = new System.Windows.Forms.TextBox();
            this.buttonDrawForMe = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGraphics)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSquare
            // 
            this.buttonSquare.Location = new System.Drawing.Point(11, 593);
            this.buttonSquare.Name = "buttonSquare";
            this.buttonSquare.Size = new System.Drawing.Size(89, 23);
            this.buttonSquare.TabIndex = 0;
            this.buttonSquare.Text = "&Draw a Square";
            this.buttonSquare.UseVisualStyleBackColor = true;
            this.buttonSquare.Click += new System.EventHandler(this.buttonSquare_Click);
            // 
            // button1x5
            // 
            this.button1x5.Location = new System.Drawing.Point(106, 593);
            this.button1x5.Name = "button1x5";
            this.button1x5.Size = new System.Drawing.Size(75, 23);
            this.button1x5.TabIndex = 1;
            this.button1x5.Text = "&1x5";
            this.button1x5.UseVisualStyleBackColor = true;
            this.button1x5.Click += new System.EventHandler(this.button1x5_Click);
            // 
            // button5x5
            // 
            this.button5x5.Location = new System.Drawing.Point(187, 593);
            this.button5x5.Name = "button5x5";
            this.button5x5.Size = new System.Drawing.Size(75, 23);
            this.button5x5.TabIndex = 2;
            this.button5x5.Text = "&5x5";
            this.button5x5.UseVisualStyleBackColor = true;
            this.button5x5.Click += new System.EventHandler(this.button5x5_Click);
            // 
            // pictureBoxGraphics
            // 
            this.pictureBoxGraphics.Location = new System.Drawing.Point(13, 13);
            this.pictureBoxGraphics.Name = "pictureBoxGraphics";
            this.pictureBoxGraphics.Size = new System.Drawing.Size(775, 574);
            this.pictureBoxGraphics.TabIndex = 3;
            this.pictureBoxGraphics.TabStop = false;
            // 
            // textBoxNumSquares
            // 
            this.textBoxNumSquares.Location = new System.Drawing.Point(268, 594);
            this.textBoxNumSquares.Name = "textBoxNumSquares";
            this.textBoxNumSquares.Size = new System.Drawing.Size(100, 20);
            this.textBoxNumSquares.TabIndex = 4;
            // 
            // buttonDrawForMe
            // 
            this.buttonDrawForMe.Location = new System.Drawing.Point(374, 593);
            this.buttonDrawForMe.Name = "buttonDrawForMe";
            this.buttonDrawForMe.Size = new System.Drawing.Size(101, 23);
            this.buttonDrawForMe.TabIndex = 5;
            this.buttonDrawForMe.Text = "Draw for &Me!";
            this.buttonDrawForMe.UseVisualStyleBackColor = true;
            this.buttonDrawForMe.Click += new System.EventHandler(this.buttonDrawForMe_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 628);
            this.Controls.Add(this.buttonDrawForMe);
            this.Controls.Add(this.textBoxNumSquares);
            this.Controls.Add(this.pictureBoxGraphics);
            this.Controls.Add(this.button5x5);
            this.Controls.Add(this.button1x5);
            this.Controls.Add(this.buttonSquare);
            this.Name = "Form1";
            this.Text = "Drawing Squares";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGraphics)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSquare;
        private System.Windows.Forms.Button button1x5;
        private System.Windows.Forms.Button button5x5;
        private System.Windows.Forms.PictureBox pictureBoxGraphics;
        private System.Windows.Forms.TextBox textBoxNumSquares;
        private System.Windows.Forms.Button buttonDrawForMe;
    }
}

