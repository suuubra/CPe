﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrawingSquares
{
    public partial class Form1 : Form
    {
        //Declare constants
        const int WIDTH_HEIGHT = 100;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonSquare_Click(object sender, EventArgs e)
        {
            //Declare variables
            Graphics paper = pictureBoxGraphics.CreateGraphics();
            Pen pen = new Pen(Color.Black, 2);
            Brush brush = new SolidBrush(Color.Red);
            int x = 0;
            int y = 0;
            //Clear the picturebox
            pictureBoxGraphics.Refresh();
            //Draw a square
            paper.FillRectangle(brush, x, y, WIDTH_HEIGHT, WIDTH_HEIGHT);
            paper.DrawRectangle(pen, x, y, WIDTH_HEIGHT, WIDTH_HEIGHT);
        }

        private void button1x5_Click(object sender, EventArgs e)
        {
            //Declare variables
            Graphics paper = pictureBoxGraphics.CreateGraphics();
            Pen pen = new Pen(Color.Black, 2);
            Brush brush = new SolidBrush(Color.Red);
            int x = 0;
            int y = 0;
            //Clear the picturebox
            pictureBoxGraphics.Refresh();
            //Draw a line of squares
            for (int i = 0; i < 5; i++)
            {
                paper.FillRectangle(brush, x, y, WIDTH_HEIGHT, WIDTH_HEIGHT);
                paper.DrawRectangle(pen, x, y, WIDTH_HEIGHT, WIDTH_HEIGHT);
                x += WIDTH_HEIGHT;
            }
        }

        private void button5x5_Click(object sender, EventArgs e)
        {
            //Declare variables
            Graphics paper = pictureBoxGraphics.CreateGraphics();
            Pen pen = new Pen(Color.Black, 2);
            Brush brush = new SolidBrush(Color.Red);
            int x = 0;
            int y = 0;
            //Clear the picturebox
            pictureBoxGraphics.Refresh();
            //For every row in the canvas
            for (int j = 0; j < 5; j++)
            {
                //Draw a line of squares
                for (int i = 0; i < 5; i++)
                {
                    paper.FillRectangle(brush, x, y, WIDTH_HEIGHT, WIDTH_HEIGHT);
                    paper.DrawRectangle(pen, x, y, WIDTH_HEIGHT, WIDTH_HEIGHT);
                    x += WIDTH_HEIGHT;
                }
                y += WIDTH_HEIGHT;
                x = 0;
            }
        }

        private void buttonDrawForMe_Click(object sender, EventArgs e)
        {
            //Declare variables
            Graphics paper = pictureBoxGraphics.CreateGraphics();
            Pen pen = new Pen(Color.Black, 2);
            Brush brush = new SolidBrush(Color.Red);
            int x = 0;
            int y = 0;
            int sideLength;
            int numSquares;
            //Try to read in the value the user entered
            if (int.TryParse(textBoxNumSquares.Text, out numSquares) == true)
            {
                //Calculate the height of each square
                sideLength = pictureBoxGraphics.Height / numSquares;
                //Clear the picturebox
                pictureBoxGraphics.Refresh();
                //For every row in the canvas
                for (int j = 0; j < numSquares; j++)
                {
                    //Draw a line of squares
                    for (int i = 0; i < numSquares; i++)
                    {
                        paper.FillRectangle(brush, x, y, sideLength, sideLength);
                        paper.DrawRectangle(pen, x, y, sideLength, sideLength);
                        x += sideLength;
                    }
                    y += sideLength;
                    x = 0;
                }
            }
            else
            {
                MessageBox.Show("Please enter a whole number, e.g. 4");
            }
        }
    }
}
